# portfolio

files for personal website

Using github pages for static homepage. Project links to elastic beanstalk

Contact form done with formspree

ResumeCards Jekyll template by Elle Kasai